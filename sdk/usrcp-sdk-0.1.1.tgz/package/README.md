# USRCP SDK Prototype

## Overview
This is a prototype SDK for the USRCP ledger system, providing event sourcing with a free tier limit of 1000 entries per database.

## Installation
```bash
npm install
```

## Building
```bash
npm run build
```

## Usage
```typescript
import { initLedger } from './dist/index.js';

const ledger = initLedger({ mode: 'random' });

ledger.appendEvent('test', { 
  type: 'init', 
  data: { hello: 'world' } 
});

const state = ledger.getState('test');
console.log('SDK Test:', state, 'Entry count:', ledger.entryCount);
```

## OpenAI Integration Stub

This SDK provides a stub for integrating with OpenAI's tool calling feature. Below is an example of how to define tools for the USRCP ledger methods and use them in a chat completion.

```typescript
import OpenAI from '@openai/openai';
import { initLedger } from './dist/index.js';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const ledger = initLedger({ mode: 'random' });

// Define tools
const tools = [
  {
    type: 'function',
    function: {
      name: 'appendEvent',
      description: 'Append an event to a USRCP ledger stream.',
      parameters: {
        type: 'object',
        properties: {
          stream: { type: 'string', description: 'The stream name.' },
          type: { type: 'string', description: 'The event type.' },
          data: { type: 'object', description: 'The event data.' }
        },
        required: ['stream', 'type', 'data']
      }
    }
  },
  {
    type: 'function',
    function: {
      name: 'getState',
      description: 'Get the current state of a USRCP ledger stream.',
      parameters: {
        type: 'object',
        properties: {
          stream: { type: 'string', description: 'The stream name.' }
        },
        required: ['stream']
      }
    }
  }
];

// Demo: Create chat completion with tools
const completion = await openai.chat.completions.create({
  model: 'gpt-4o',
  messages: [{ role: 'user', content: 'Append a user message event to the chat stream.' }],
  tools: tools
});

// Assume tool call for appendEvent
if (completion.choices[0].message.tool_calls) {
  const toolCall = completion.choices[0].message.tool_calls[0];
  if (toolCall.function.name === 'appendEvent') {
    const args = JSON.parse(toolCall.function.arguments);
    ledger.appendEvent('chat', { type: 'user_message', data: args.data });
    
    // Get updated state
    const state = ledger.getState('chat');
    console.log('Updated state:', state);
  }
}
```

Note: In production, use usrcp:// URIs for secure ledger calls (e.g., usrcp://ledger/appendEvent).

## Grok/xAI Integration Stub

This SDK provides a stub for integrating with Grok/xAI's tool calling feature, which mirrors OpenAI's format. Use the OpenAI SDK with xAI's API endpoint. Reuse `openaiToolSchema` (or `xaiToolSchema` alias) for tools, as Grok supports the OpenAI tool format.

```typescript
import OpenAI from 'openai';
import { initLedger, openaiToolSchema } from './dist/index.js';

const xai = new OpenAI({
  baseURL: 'https://api.x.ai/v1',
  apiKey: process.env.XAI_API_KEY,
});

const ledger = initLedger({ mode: 'random' });

// Reuse tool schema
const tools = openaiToolSchema();

// Demo: Chat completion with tools
const completion = await xai.chat.completions.create({
  model: 'grok-beta',
  messages: [{ role: 'user', content: 'Append a user message event to the chat stream.' }],
  tools: tools
});

// Assume tool call for appendEvent
if (completion.choices[0].message.tool_calls) {
  const toolCall = completion.choices[0].message.tool_calls[0];
  if (toolCall.function.name === 'appendEvent') {
    const args = JSON.parse(toolCall.function.arguments);
    ledger.appendEvent('chat', { type: 'user_message', data: args.data });
    
    // Get updated state
    const state = ledger.getState('chat');
    console.log('Updated state:', state);
  }
}
```

Note: Grok's tool calling mirrors OpenAI. In production, use usrcp:// URIs for secure ledger calls (e.g., usrcp://ledger/appendEvent).

## Free Tier Limits
- Maximum 1000 events per ledger.
- Exceeding this limit will throw an error on `getState` calls.

## Testing
Run the demo:
```bash
npx tsx test/demo.ts
```
Or compile and run:
```bash
tsc test/demo.ts --outDir dist/test
node dist/test/demo.js
```

## Next Steps
- Implement full event reducers for complex state management.
- Add Jest tests for unit testing.
- Support multiple streams and advanced querying.
- Consider paid tier features for higher limits.