import initSqlJs, { Database as SqliteDatabase } from 'sql.js';

export interface LedgerConfig {
  mode: 'random' | string;
}

export interface Event {
  type: string;
  data: any;
}

export interface Ledger {
  appendEvent(stream: string, event: Event): void;
  getState(stream: string): any;
  entryCount: number;
}

class USRCPLedger implements Ledger {
  private db: SqliteDatabase;
  public entryCount: number = 0;

  constructor(db: SqliteDatabase) {
    this.db = db;
    
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        stream TEXT NOT NULL,
        type TEXT NOT NULL,
        data TEXT NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Initialize entry count
    const countStmt = this.db.prepare('SELECT COUNT(*) FROM events');
    const countRow = countStmt.get() as [number];
    this.entryCount = countRow ? countRow[0] : 0;
  }

  appendEvent(stream: string, event: Event): void {
    const stmt = this.db.prepare(
      'INSERT INTO events (stream, type, data) VALUES (?, ?, ?)'
    );
    stmt.run([stream, event.type, JSON.stringify(event.data)]);
    stmt.free();
    const countStmt = this.db.prepare('SELECT COUNT(*) FROM events');
    const countRow = countStmt.get() as [number];
    this.entryCount = countRow ? countRow[0] : 0;
    countStmt.free();
  }

  getState(stream: string): any {
    if (this.entryCount > 1000) {
      throw new Error('Free tier limit exceeded: maximum 1000 entries allowed');
    }
    const stmt = this.db.prepare(
      'SELECT type, data FROM events WHERE stream = ? ORDER BY id ASC'
    );
    stmt.bind([stream]);
    const events: {type: string, data: string}[] = [];
    while (stmt.step()) {
      const row = stmt.getAsObject() as {type: string, data: string};
      events.push(row);
    }
    stmt.free();

    let state: any = {};
    for (const ev of events) {
      const data = JSON.parse(ev.data);
      switch (ev.type) {
        case 'init':
          state = { ...state, ...data };
          break;
        // Add more event types and reducers as needed
        default:
          // For now, just append to state
          state[ev.type] = data;
      }
    }
    return state;
  }
}

export async function initLedger(config: LedgerConfig): Promise<Ledger> {
  const Sqlite = await initSqlJs();
  const db = new Sqlite.Database();
  const ledger = new USRCPLedger(db);
  // entryCount already 0 for new in-memory DB
  return ledger;
}

export interface OpenAITool {
  type: 'function';
  function: {
    name: string;
    description: string;
    parameters: {
      type: 'object';
      properties: Record<string, any>;
      required: string[];
    };
  };
}

export function openaiToolSchema(): OpenAITool[] {
  return [
    {
      type: 'function',
      function: {
        name: 'appendEvent',
        description: 'Append an event to a USRCP ledger stream using usrcp://ledger/appendEvent URI semantics.',
        parameters: {
          type: 'object',
          properties: {
            stream: { type: 'string', description: 'The ledger stream/domain name.' },
            type: { type: 'string', description: 'The event type.' },
            data: { type: 'object', description: 'The event data payload.' }
          },
          required: ['stream', 'type', 'data']
        }
      }
    },
    {
      type: 'function',
      function: {
        name: 'getState',
        description: 'Retrieve the current state of a USRCP ledger stream using usrcp://ledger/getState URI semantics.',
        parameters: {
          type: 'object',
          properties: {
            stream: { type: 'string', description: 'The ledger stream/domain name.' }
          },
          required: ['stream']
        }
      }
    }
  ];
}

export function xaiToolSchema(): OpenAITool[] {
  // Alias to openaiToolSchema as Grok/xAI mirrors OpenAI tool format with usrcp:// URI support
  return openaiToolSchema();
}